source test_constants.sh &&
rm *.class &&
source test_globals.sh &&
rm *.class &&
source test_controls.sh &&
rm *.class &&
source test_functions.sh &&
rm *.class &&
source test_functions1.sh &&
rm *.class &&
source test_builtin.sh &&
rm *.class &&
source test_break.sh &&
rm *.class &&
source test_scope.sh &&
rm *.class
