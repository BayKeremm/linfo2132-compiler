source test_constants.sh &&
rm ./codegen_test_files/*.class &&
source test_globals.sh &&
rm ./codegen_test_files/*.class &&
source test_controls.sh &&
rm ./codegen_test_files/*.class &&
source test_functions.sh &&
rm ./codegen_test_files/*.class &&
source test_functions1.sh &&
rm ./codegen_test_files/*.class &&
source test_builtin.sh &&
rm ./codegen_test_files/*.class &&
source test_break.sh &&
rm ./codegen_test_files/*.class &&
source test_scope.sh &&
rm ./codegen_test_files/*.class
