package compiler.Parser;


public interface StatementChecker {
    void typeAnalyse(NodeVisitor v);
}
