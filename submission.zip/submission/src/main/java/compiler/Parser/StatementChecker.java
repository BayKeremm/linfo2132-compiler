package compiler.Parser;


public interface StatementChecker {
    void typeAnalyse(TypeVisitor v);
}
