package compiler.Parser;

public abstract class ASTNode {
    public static Program program;


    public ASTNode(){

    }

    public abstract boolean equals(Object o);
}
