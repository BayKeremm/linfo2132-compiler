package compiler.bytecodegen;

public interface ByteCodeGenerator {
    void codeGen(ByteVisitor b);
}
